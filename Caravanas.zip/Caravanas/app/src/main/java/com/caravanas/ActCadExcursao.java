package com.caravanas;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ActCadExcursao extends AppCompatActivity {

    private EditText editNome;
    private EditText editLocalSaida;
    private EditText editData;
    private EditText editTelefone;

    private Button criarExcursaoButton;
    private Button voltarButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_cad_excursao);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        editNome = (EditText) findViewById(R.id.editNome);
        editLocalSaida = (EditText) findViewById(R.id.editLocalSaida);
        editData = (EditText) findViewById(R.id.editData);
        editData = (EditText) findViewById(R.id.editTelefone);


        criarExcursaoButton = findViewById(R.id.criarExcursaoButton);
        voltarButton = findViewById(R.id.voltarButton);


        voltarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(ActCadExcursao.this, ActMain.class);
                startActivity(it);
            }
        });

        criarExcursaoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

    }




}
